<footer id="footer_app" class="bg-white border-t border-gray-200 mt-10 md:ml-64">
    <div class="p-4 text-sm text-center text-gray-500">
        © {{ date('Y') }} {{ setting('app_name') }} — Sistem Presensi QR-Code
        <p>by :
            <a class="font-bold hover:text-orange-500" href="https://instagram.com/el_miro23" target="_blank">
                Hendrik J.R Samkay
            </a>    
        </p>
    </div>
</footer>
