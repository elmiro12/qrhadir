@props(['label'])

<li class="px-4 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest bg-gray-50/50">
    {{ $label }}
</li>
