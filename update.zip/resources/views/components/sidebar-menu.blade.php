@props([
    'link' => 'home',           // menu link
    'activeLink' => 'home',     // menu active route
    'icon' => 'home',             // material icon name, ex: "login"
    'label' => 'left',   // left | right
])
<li {{ $attributes->merge([
        'class' => ""
    ]) }}>
<a href="{{ route($link) }}"
   class="flex items-center gap-3 p-2 rounded {{ isActive($activeLink) }}">
    <x-icon name="{{ $icon }}" />
    <span class="menu-label">{{ $label }}</span>
</a>
</li>